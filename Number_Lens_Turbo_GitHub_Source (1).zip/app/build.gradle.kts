plugins { id("com.android.application") }

android {
    namespace = "com.numberlens.turbo"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.numberlens.turbo"
        minSdk = 29
        targetSdk = 35
        versionCode = 1
        versionName = "7.1-turbo"
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
}

dependencies { implementation("androidx.webkit:webkit:1.13.0") }
