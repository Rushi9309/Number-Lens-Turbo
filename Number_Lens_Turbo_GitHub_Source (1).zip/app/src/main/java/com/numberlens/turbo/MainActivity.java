package com.numberlens.turbo;

import android.app.Activity;
import android.os.Bundle;
import android.os.Environment;
import android.os.Build;
import android.provider.MediaStore;
import android.content.ContentValues;
import android.content.Intent;
import android.content.ActivityNotFoundException;
import android.net.Uri;
import android.webkit.*;
import android.widget.Toast;
import android.graphics.Color;
import android.util.Base64;
import androidx.webkit.WebViewAssetLoader;
import androidx.webkit.WebViewClientCompat;
import java.io.OutputStream;
import java.util.Locale;

public class MainActivity extends Activity {
    private static final int PICK_PDF = 3241;
    private WebView webView;
    private ValueCallback<Uri[]> pdfCallback;
    private final WebViewAssetLoader assets = new WebViewAssetLoader.Builder()
        .addPathHandler("/assets/", new WebViewAssetLoader.AssetsPathHandler(this)).build();

    @Override public void onCreate(Bundle state){
        super.onCreate(state);
        getWindow().setStatusBarColor(Color.rgb(16,24,39));
        getWindow().setNavigationBarColor(Color.rgb(16,24,39));
        webView = new WebView(this);
        setContentView(webView);
        WebSettings settings=webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setAllowFileAccess(false);
        settings.setAllowContentAccess(true);
        settings.setAllowFileAccessFromFileURLs(false);
        settings.setAllowUniversalAccessFromFileURLs(false);
        settings.setCacheMode(WebSettings.LOAD_DEFAULT);
        webView.setLayerType(WebView.LAYER_TYPE_HARDWARE, null);
        webView.addJavascriptInterface(new AndroidFiles(),"AndroidFiles");
        webView.setWebViewClient(new WebViewClientCompat(){
            @Override public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request){
                return assets.shouldInterceptRequest(request.getUrl());
            }
        });
        webView.setWebChromeClient(new WebChromeClient(){
            @Override public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback, FileChooserParams params){
                if(pdfCallback!=null)pdfCallback.onReceiveValue(null);
                pdfCallback=callback;
                Intent intent=new Intent(Intent.ACTION_OPEN_DOCUMENT);
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                intent.setType("application/pdf");
                try{startActivityForResult(intent,PICK_PDF);}catch(ActivityNotFoundException e){pdfCallback.onReceiveValue(null);pdfCallback=null;return false;}
                return true;
            }
        });
        webView.loadUrl("https://appassets.androidplatform.net/assets/index.html");
    }

    @Override protected void onActivityResult(int requestCode,int resultCode,Intent data){
        super.onActivityResult(requestCode,resultCode,data);
        if(requestCode==PICK_PDF){
            if(pdfCallback!=null){
                Uri uri=(resultCode==RESULT_OK && data!=null)?data.getData():null;
                pdfCallback.onReceiveValue(uri==null?null:new Uri[]{uri});pdfCallback=null;
            }
        }
    }
    @Override public void onBackPressed(){
        if(webView!=null && webView.canGoBack())webView.goBack();
        else super.onBackPressed();
    }
    public class AndroidFiles {
        @JavascriptInterface public void saveDataUrl(String filename,String dataUrl){
            new Thread(()->{
                try{
                    int comma=dataUrl.indexOf(',');
                    if(comma<0 || comma>160)throw new IllegalArgumentException("Invalid data URL");
                    String meta=dataUrl.substring(0,comma);
                    if(!meta.endsWith(";base64"))throw new IllegalArgumentException("Only base64 data supported");
                    String mime=meta.substring(5,meta.indexOf(';'));
                    if(!(mime.equals("image/png")||mime.equals("application/json")||mime.equals("text/csv")))throw new IllegalArgumentException("Unsupported file type");
                    String safe=filename.replaceAll("[^a-zA-Z0-9._-]","_");
                    byte[] bytes=Base64.decode(dataUrl.substring(comma+1),Base64.DEFAULT);
                    ContentValues values=new ContentValues();
                    values.put(MediaStore.Downloads.DISPLAY_NAME,safe);
                    values.put(MediaStore.Downloads.MIME_TYPE,mime);
                    values.put(MediaStore.Downloads.RELATIVE_PATH,Environment.DIRECTORY_DOWNLOADS+"/NumberLens");
                    Uri destination=getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI,values);
                    if(destination==null)throw new Exception("Cannot create file");
                    try(OutputStream stream=getContentResolver().openOutputStream(destination)){
                        if(stream==null)throw new Exception("Cannot write file");
                        stream.write(bytes);
                    }
                    runOnUiThread(()->Toast.makeText(MainActivity.this,"Saved to Downloads/NumberLens",Toast.LENGTH_LONG).show());
                }catch(Exception error){runOnUiThread(()->Toast.makeText(MainActivity.this,"Save failed: "+error.getMessage(),Toast.LENGTH_LONG).show());}
            }).start();
        }
    }
}
