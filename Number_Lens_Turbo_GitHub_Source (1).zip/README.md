# Number Lens Turbo — GitHub Android APK source

An Android WebView app packaging the exact-main-range Number Pattern Lens V7 UI and detection logic.

## Build using GitHub on Android phone

1. Create a **new empty GitHub repository** (public or private) and upload **the contents of this ZIP**, keeping the folders intact (especially `.github/workflows/build-apk.yml`). GitHub's mobile browser may require **Desktop site** to upload multiple files/folders. Alternatively, use a Git client app.
2. Go to the repository **Actions** tab and enable Actions if prompted.
3. Choose **Build Number Lens Turbo APK** and select **Run workflow**, or push a commit to `main`.
4. Open the completed run, tap **Number-Lens-Turbo-debug-APK**, unzip the artifact, and install `app-debug.apk` on Android.
5. If updating an older APK with a different signing key, uninstall the old APK first (back up exported JSON records before uninstalling).

## Improvements included

- Starts with **Fast HD** instead of heavy 3x Ultra HD; switch to Ultra HD manually when needed.
- Smaller render cost during fast scroll; more scroll overscan.
- Batches local record persistence instead of writing all JSON synchronously on every set.
- Uses secure WebViewAssetLoader HTTPS local origin; supports Android PDF picker and downloads to `Downloads/NumberLens`.
- Retains V7 Main exact-number range grouping, UID vertical-line family pairing, Set 1/2/3 gating, and record duplicate checks.

## Important limitations

This is an **optimized WebView APK**, not a rewrite as a native PDF/detection engine. High frame rates and perfectly reliable detection during extremely fast scrolling are **not guaranteed**, particularly for large image-only PDF scans, heavy OCR, and older phones. The application loads PDF.js and optional Tesseract.js from public CDNs, so an internet connection is needed to load those libraries. The PDFs themselves are selected from the phone and processed on-device. This source is not a compiled APK and has not been device-tested.

The debug APK is for personal testing. For distribution, build and sign a release APK/AAB with your own release signing key.
